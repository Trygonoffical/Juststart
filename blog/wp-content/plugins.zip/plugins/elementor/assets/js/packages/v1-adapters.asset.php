<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-v1-adapters','deps'=>['react',],];