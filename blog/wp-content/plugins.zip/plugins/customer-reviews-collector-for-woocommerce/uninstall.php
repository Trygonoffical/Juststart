<?php
require_once plugin_dir_path( __FILE__ ) . 'trustindex-collector-plugin.class.php';
$trustindex_collector = new TrustindexCollectorPlugin(__FILE__, "3.4");
$trustindex_collector->uninstall();
?>