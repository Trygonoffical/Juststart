<?php
$pagination_links = [
[
'text' => TrustindexCollectorPlugin::___('Previous'),
'page' => $list_page_index - 1,
'disabled' => $list_page_index <= 1
]
];
if($results->max_num_pages < 9)
{
for($i = 1; $i <= $results->max_num_pages; $i++)
{
$pagination_links []= [
'page' => $i,
'active' => $list_page_index == $i
];
}
}
else if($results->max_num_pages > 7)
{
if($list_page_index <= 4)
{
for($i = 1; $i < 6; $i++)
{
$pagination_links []= [
'page' => $i,
'active' => $list_page_index == $i,
];
}
$pagination_links []= [ 'text' => '...', 'disabled' => true ];
$pagination_links []= [ 'page' => $results->max_num_pages ];
}
else if($results->max_num_pages - 3 > $list_page_index && $list_page_index > 2)
{
$pagination_links []= [ 'page' => 1 ];
$pagination_links []= [ 'text' => '...', 'disabled' => true ];
for($i = $list_page_index - 1; $i <= $list_page_index + 1; $i++)
{
$pagination_links []= [
'page' => $i,
'active' => $list_page_index == $i,
];
}
$pagination_links []= [ 'text' => '...', 'disabled' => true ];
$pagination_links []= [ 'page' => $results->max_num_pages ];
}
else
{
$pagination_links []= [ 'page' => 1 ];
$pagination_links []= [ 'text' => '...', 'disabled' => true ];
for($i = $results->max_num_pages - 4; $i <= $results->max_num_pages; $i++)
{
$pagination_links []= [
'page' => $i,
'active' => $list_page_index == $i,
];
}
}
}
$pagination_links []= [
'text' => TrustindexCollectorPlugin::___('Next'),
'page' => $list_page_index + 1,
'disabled' => $list_page_index >= $results->max_num_pages
];
?>
<nav>
<ul class="pagination justify-content-end">
<?php foreach($pagination_links as $link): ?>
<li class="page-item<?php if(isset($link['disabled']) && $link['disabled']): ?> disabled<?php endif; ?><?php if(isset($link['active']) && $link['active']): ?> active<?php endif; ?>">
<?php if(isset($link['disabled']) && $link['disabled']): ?>
<a class="page-link " href="#" tabindex="-1" aria-disabled="true">
<?php else: ?>
<a class="page-link " href="<?php echo esc_url(preg_replace('/&pi=\d+/', '&pi='. $link['page'], $page_url)); ?>">
<?php endif; ?>
<?php echo esc_html(isset($link['text']) ? $link['text'] : $link['page']); ?>
</a>
</li>
<?php endforeach; ?>
</ul>
</nav>