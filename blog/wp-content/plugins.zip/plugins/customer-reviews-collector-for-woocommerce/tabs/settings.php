<?php
defined('ABSPATH') or die('No script kiddies please!');
function save_settings_state($new_settings_state)
{
global $settings_state;
global $trustindex_collector;
if($settings_state <= $new_settings_state)
{
update_option($trustindex_collector->get_option_name('settings-state'), $new_settings_state, false);
}
}
if($ti_command == 'save-platform-url')
{
check_admin_referer('ti-collector-save-platform-url');
$trustindex_collector->save_option_from_request('platform-url', 'array');
save_settings_state(2);
exit;
}
else if($ti_command == 'save-trigger')
{
check_admin_referer('ti-collector-save-trigger');
$trustindex_collector->save_option_from_request('trigger-delay');
$trustindex_collector->save_option_from_request('trigger-event');
$trustindex_collector->save_option_from_request('frequency');
save_settings_state(3);
exit;
}
else if($ti_command == 'save-email-settings')
{
check_admin_referer('ti-collector-save-email-settings');
$trustindex_collector->save_option_from_request('email-sender');
$trustindex_collector->save_option_from_request('email-sender-email');
$trustindex_collector->save_option_from_request('email-subject');
$trustindex_collector->save_option_from_request('email-text', 'text');
$trustindex_collector->save_option_from_request('email-footer-text', 'text');
if(isset($_REQUEST['logo-image']) && $_REQUEST['logo-image'])
{
if($_REQUEST['logo-image'] == 'delete')
{
$file = wp_upload_dir()['basedir'] . DIRECTORY_SEPARATOR . $trustindex_collector->get_email_logo_filename();
if(file_exists($file))
{
unlink($file);
}
}
else
{
$trustindex_collector->uploadLogoImage($_REQUEST['logo-image']);
}
}
save_settings_state(4);
exit;
}
else if($ti_command == 'save-negative-invitation')
{
check_admin_referer('ti-collector-save-negative-invitation');
update_option($trustindex_collector->get_option_name('campaign-active'), 1, false);
save_settings_state(4);
exit;
}
else if($ti_command == 'save-support-language')
{
$trustindex_collector->save_option_from_request('support-language');
exit;
}
else if($ti_command == 'test-email')
{
$email = isset($_POST['email']) ? sanitize_email($_POST['email']) : "";
if($email)
{
if(isset($_POST['email-text']))
{
$_POST['email-text'] = wp_kses_post(stripslashes($_POST['email-text']));
}
if(isset($_POST['email-footer-text']))
{
$_POST['email-footer-text'] = wp_kses_post(stripslashes($_POST['email-footer-text']));
}
$_POST['customer_full_name'] = 'Test Customer';
if(isset($_POST['logo-image']) && $_POST['logo-image'] != 'delete')
{
$_POST['logo-image'] = $trustindex_collector->uploadLogoImage($_POST['logo-image'], 'ti-collector-email-logo-tmp.png');
if($_POST['logo-image'])
{
$_POST['logo-image'] .= '?' . time();
}
}
$trustindex_collector->sendMail($email, $_POST);
}
exit;
}
$ti_settings = [];
foreach($trustindex_collector->get_default_settings() as $name => $default)
{
$ti_settings[ $name ] = get_option($trustindex_collector->get_option_name($name), $default);
}
$support_locales = array_map(function($tmp) {
return str_replace(TrustindexCollectorPlugin::$text_domain . '-', '', $tmp);
}, get_available_languages($trustindex_collector->get_plugin_dir() . 'languages'));
require_once(ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'translation-install.php');
$translations = wp_get_available_translations();
$support_languages = [];
foreach($support_locales as $l_index)
{
$support_languages[ $l_index ] = isset($translations[ $l_index ]) ? $translations[ $l_index ]['english_name'] : $l_index;
}
$support_languages['en'] = 'English';
asort($support_languages);
?>
<div class="plugin-head"><?php echo TrustindexCollectorPlugin::___('Set up automatic review requests'); ?></div>
<div class="plugin-body">
<div class="accordion accordion-flush accordion-check" id="ti-settings">
<div class="accordion-item">
<h2 class="accordion-header">
<button class="accordion-button disabled<?php if($settings_state != 1): ?> collapsed<?php endif; ?><?php if($settings_state > 1): ?> done<?php endif; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#ti-platform-url" aria-expanded="false" aria-controls="ti-platform-url">
<div class="acc-check"><span></span></div>
<?php echo TrustindexCollectorPlugin::___('Where do you want to collect reviews'); ?>
</button>
</h2>
<form id="ti-platform-url" method="post" class="accordion-collapse collapse<?php if($settings_state == 1): ?> show<?php endif; ?>" data-bs-parent="#ti-settings" data-platform-urls='<?php echo json_encode($ti_settings['platform-url']); ?>'>
<input type="hidden" name="command" value="save-platform-url" />
<?php wp_nonce_field('ti-collector-save-platform-url'); ?>
<div class="accordion-body">
<div class="alert alert-danger alert-hidden alert-url-invalid"><?php echo TrustindexCollectorPlugin::___('URL is invalid'); ?></div>
<div class="alert alert-danger alert-hidden alert-percent-invalid"><?php echo TrustindexCollectorPlugin::___('The total percentage must be 100%%'); ?></div>
<p class="text-muted mb-4">
<strong><?php echo TrustindexCollectorPlugin::___('Connect your Google Business Profile to get your own Google review writing form URL.'); ?></strong><br />
<?php echo TrustindexCollectorPlugin::___('This URL will be inserted into the review request email.'); ?><br />
<?php echo TrustindexCollectorPlugin::___('Alternatively you can enter the URL of any review platform by selecting the custom option.'); ?>
</p>
<div id="platform-urls"></div>
<a href="#" class="link-clean btn-add-platform-url">
<span class="dashicons dashicons-plus-alt" style="margin-top: 2px"></span> <?php echo TrustindexCollectorPlugin::___('add URL'); ?>
</a>
<p class="text-muted platform-urls-info d-none"><?php echo TrustindexCollectorPlugin::___('Each link will appear in the email according to %% probability that you define.'); ?></p>
<div class="row">
<div class="col-12 col-sm justify-content-end d-flex">
<?php if($settings_state >= 2): ?>
<a href="#" class="btn btn-primary btn-next btn-default-disabled btn-no-next-step"><?php echo TrustindexCollectorPlugin::___('Save changes'); ?></a>
<?php else: ?>
<a href="#" class="btn btn-primary btn-next"><?php echo TrustindexCollectorPlugin::___('Next'); ?></a>
<?php endif; ?>
</div>
</div>
</div>
</form>
</div>
<div class="accordion-item">
<h2 class="accordion-header">
<button class="accordion-button disabled<?php if($settings_state != 2): ?> collapsed<?php endif; ?><?php if($settings_state > 2): ?> done<?php endif; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#ti-trigger" aria-expanded="false" aria-controls="ti-trigger">
<div class="acc-check"><span></span></div>
<?php echo TrustindexCollectorPlugin::___('When to send e-mail request'); ?>
</button>
</h2>
<form id="ti-trigger" method="post" class="accordion-collapse collapse<?php if($settings_state == 2): ?> show<?php endif; ?>" data-bs-parent="#ti-settings">
<input type="hidden" name="command" value="save-trigger" />
<?php wp_nonce_field('ti-collector-save-trigger'); ?>
<div class="accordion-body">
<div class="row">
<label class="col-12 col-sm-auto col-form-label"><?php echo TrustindexCollectorPlugin::___('Send'); ?></label>
<div class="col-12 col-sm-auto">
<select class="form-select" name="trigger-delay">
<option value="0"<?php if($ti_settings['trigger-delay'] == 0): ?> selected<?php endif; ?>><?php echo TrustindexCollectorPlugin::___('immediately'); ?></option>
<?php foreach([ 1, 2, 3, 4, 5, 6, 7, 14, 21 ] as $days): ?>
<option value="<?php echo esc_attr($days); ?>"<?php if($ti_settings['trigger-delay'] == $days): ?> selected<?php endif; ?>><?php echo TrustindexCollectorPlugin::___('after %s days', [ $days ]); ?></option>
<?php endforeach; ?>
</select>
</div>
<label class="col-12 col-sm-auto col-form-label"><?php echo TrustindexCollectorPlugin::___("if order is"); ?></label>
<div class="col-auto">
<select class="form-select" name="trigger-event">
<?php foreach(wc_get_order_statuses() as $status => $name): ?>
<option value="<?php echo esc_attr($status); ?>"<?php if($ti_settings['trigger-event'] == $status): ?> selected<?php endif; ?>>
<?php echo esc_html($name); ?>
</option>
<?php endforeach; ?>
</select>
</div>
<label class="col-12 col-sm-auto col-form-label"><?php echo TrustindexCollectorPlugin::___("Frequency"); ?></label>
<div class="col-12 col-sm-auto">
<select class="form-select" name="frequency">
<option value="0"<?php if($ti_settings['frequency'] == 0): ?> selected<?php endif; ?>><?php echo TrustindexCollectorPlugin::___('After each order'); ?></option>
<?php foreach([ 1, 2, 3, 4, 5, 6 ] as $months): ?>
<option value="<?php echo esc_attr($months); ?>"<?php if($ti_settings['frequency'] == $months): ?> selected<?php endif; ?>><?php echo TrustindexCollectorPlugin::___('No more than 1 email in %d month', [ $months ]); ?></option>
<?php endforeach; ?>
</select>
</div>
</div>
<div class="row">
<div class="col justify-content-end d-flex">
<?php if($settings_state >= 3): ?>
<a href="#" class="btn btn-primary btn-next btn-default-disabled btn-no-next-step"><?php echo TrustindexCollectorPlugin::___('Save changes'); ?></a>
<?php else: ?>
<a href="#" class="btn btn-primary btn-next"><?php echo TrustindexCollectorPlugin::___('Next'); ?></a>
<?php endif; ?>
</div>
</div>
</div>
</form>
</div>
<div class="accordion-item">
<h2 class="accordion-header">
<button class="accordion-button disabled<?php if(!($settings_state == 3 || $trustindex_collector->is_campaign_active())): ?> collapsed<?php endif; ?><?php if($settings_state > 3): ?> done<?php endif; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#ti-email-settings" aria-expanded="false" aria-controls="ti-email-settings">
<div class="acc-check"><span></span></div>
<?php echo TrustindexCollectorPlugin::___('E-mail customization'); ?>
</button>
</h2>
<form id="ti-email-settings" method="post" class="accordion-collapse collapse<?php if($settings_state == 3 || $trustindex_collector->is_campaign_active()): ?> show<?php endif; ?>" data-bs-parent="#ti-settings">
<input type="hidden" name="command" value="save-email-settings" />
<?php wp_nonce_field('ti-collector-save-email-settings'); ?>
<div class="accordion-body">
<div class="alert alert-danger alert-hidden alert-empty"><?php echo TrustindexCollectorPlugin::___('Fill all fields'); ?></div>
<div class="alert alert-danger alert-hidden alert-email-invalid"><?php echo TrustindexCollectorPlugin::___('Sender e-mail is invalid'); ?></div>
<div class="row">
<label class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('Sender name'); ?></label>
<div class="col-12 col-sm">
<input type="text" class="form-control" name="email-sender" value="<?php echo esc_attr($ti_settings['email-sender']); ?>" placeholder="<?php echo TrustindexCollectorPlugin::___('Sender name'); ?>" autocomplete="new-password" />
</div>
</div>
<div class="row">
<label class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('Sender e-mail'); ?></label>
<div class="col-12 col-sm">
<input type="text" class="form-control" name="email-sender-email" value="<?php echo esc_attr($ti_settings['email-sender-email']); ?>" placeholder="<?php echo TrustindexCollectorPlugin::___('Sender e-mail'); ?>" />
<small class="text-danger" style="display: none"><?php echo TrustindexCollectorPlugin::___("Sender e-mail must be on the site's domain address so that the e-mails do not end up in spam."); ?></small>
</div>
</div>
<div class="row">
<label class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('E-mail subject'); ?></label>
<div class="col-12 col-sm">
<input type="text" class="form-control" name="email-subject" value="<?php echo esc_attr($ti_settings['email-subject']); ?>" placeholder="<?php echo TrustindexCollectorPlugin::___('E-mail subject'); ?>" autocomplete="new-password" />
</div>
</div>
<div class="row">
<?php $has_logo_image = file_exists(wp_upload_dir()['basedir'] . DIRECTORY_SEPARATOR . $trustindex_collector->get_email_logo_filename()); ?>
<label class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('E-mail logo'); ?></label>
<div class="col-12 col-sm">
<input name="logo-image" id="ti-collector-email-logo-image-input" type="hidden" />
<input type="file" accept=".jpg, .png" style="display: none">
<a href="#" class="btn btn-primary btn-email-logo-upload" data-browse-text="<?php echo TrustindexCollectorPlugin::___("Browse image"); ?>" data-change-text="<?php echo TrustindexCollectorPlugin::___("Change image"); ?>"><?php echo TrustindexCollectorPlugin::___($has_logo_image ? "Change image" : "Browse image"); ?></a>
<a href="#" class="btn btn-danger btn-email-logo-delete<?php if(!$has_logo_image): ?> d-none<?php endif; ?>"><?php echo TrustindexCollectorPlugin::___("Delete"); ?></a>
</div>
</div>
<div class="email-config mt-4 mb-4">
<nav>
<div class="nav nav-tabs" id="nav-tab" role="tablist">
<button class="nav-link active" id="ti-email-preview-tab" data-bs-toggle="tab" data-bs-target="#ti-email-preview" type="button" role="tab" aria-controls="ti-email-preview" aria-selected="false"><?php echo TrustindexCollectorPlugin::___('E-mail preview'); ?></button>
<button class="nav-link" id="ti-edit-email-tab" data-bs-toggle="tab" data-bs-target="#ti-edit-email" type="button" role="tab" aria-controls="ti-edit-email" aria-selected="true"><?php echo TrustindexCollectorPlugin::___('Edit e-mail'); ?></button>
</div>
</nav>
<div class="tab-content" id="nav-tabContent">
<div class="tab-pane fade show active" id="ti-email-preview" role="tabpanel" aria-labelledby="email-prev-tab">
<iframe id="ti-email-preview-iframe" data-url="<?php echo $trustindex_collector->get_email_template_url(); ?>"></iframe>
</div>
<div class="tab-pane fade" id="ti-edit-email" role="tabpanel" aria-labelledby="edit-email-tab">
<?php if(function_exists('wp_editor')): ?>
<?php wp_editor($ti_settings['email-text'], 'email-text', [
'media_buttons' => false,
'tinymce' => [
'toolbar1' => 'undo,redo,fontsizeselect,bold,italic,underline,alignleft,aligncenter,alignright,hr',
'toolbar2' => '',
'toolbar3' => '',
'toolbar4' => ''
],
'wpautop' => true
]); ?>
<?php else: ?>
<textarea class="form-control" id="email-text" name="email-text" rows="15"><?php echo esc_textarea($ti_settings['email-text']); ?></textarea>
<?php endif; ?>
<div class="p-4">
<div class="row">
<label class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('E-mail footer text'); ?></label>
<div class="col-12 col-sm">
<textarea class="form-control" name="email-footer-text" placeholder="<?php echo TrustindexCollectorPlugin::___('E-mail footer text'); ?>"><?php echo esc_textarea($ti_settings['email-footer-text']); ?></textarea>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="alert alert-test-email alert-danger alert-hidden alert-test-email-invalid"><?php echo TrustindexCollectorPlugin::___('E-mail is invalid'); ?></div>
<div class="alert alert-test-email alert-success alert-hidden"><?php echo TrustindexCollectorPlugin::___('E-mail sent'); ?></div>
<div class="row">
<label class="col-12 col-sm-auto col-form-label"><?php echo TrustindexCollectorPlugin::___('Send test e-mail to'); ?></label>
<div class="col-12 col-sm">
<input type="email" id="ti-test-email-input" class="form-control" value="<?php echo esc_attr($current_user->user_email); ?>" />
</div>
<div class="col-12 col-sm-auto">
<a href="#" class="btn btn-light btn-send-test-email"><?php echo TrustindexCollectorPlugin::___('Send'); ?></a>
</div>
</div>
<div class="row">
<div class="col justify-content-end d-flex">
<?php if($settings_state > 3 || $trustindex_collector->is_campaign_active()): ?>
<a href="#" class="btn btn-primary btn-next btn-default-disabled btn-no-next-step"><?php echo TrustindexCollectorPlugin::___('Save changes'); ?></a>
<?php else: ?>
<a href="#" class="btn btn-primary btn-next"><?php echo TrustindexCollectorPlugin::___('Next'); ?></a>
<?php endif; ?>
</div>
</div>
</div>
</form>
</div>
<div class="accordion-item">
<h2 class="accordion-header">
<button class="accordion-button disabled<?php if($settings_state != 4 || $trustindex_collector->is_campaign_active()): ?> collapsed<?php endif; ?><?php if($trustindex_collector->is_campaign_active()): ?> done<?php endif; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#ti-negative-invitation" aria-expanded="false" aria-controls="ti-negative-invitation">
<div class="acc-check"><span></span></div>
<?php echo TrustindexCollectorPlugin::___('Avoid negative reviews with intelligent invitation system'); ?>
</button>
</h2>
<form id="ti-negative-invitation" method="post" class="accordion-collapse collapse<?php if($settings_state == 4 && !$trustindex_collector->is_campaign_active()): ?> show<?php endif; ?>" data-bs-parent="#ti-settings">
<input type="hidden" name="command" value="save-negative-invitation" />
<?php wp_nonce_field('ti-collector-save-negative-invitation'); ?>
<div class="accordion-body">
<p><?php echo TrustindexCollectorPlugin::___('If your client chooses 1, 2 or 3 stars, we do not redirect them to write a review right away. Instead, we offer the option to contact your customer support directly to resolve the issue.'); ?></p>
<div class="row g-2">
<label for="" class="col-12 col-sm-4 col-md-3 col-form-label"><?php echo TrustindexCollectorPlugin::___('Feedback form language'); ?></label>
<div class="col-auto">
<select class="form-select feedback-form-language">
<?php foreach($support_languages as $l_index => $name): ?>
<option value="<?php echo $l_index; ?>" <?php if($ti_settings['support-language'] == $l_index): ?>selected<?php endif; ?>><?php echo $name; ?></option>
<?php endforeach; ?>
</select>
</div>
<div class="col-auto">
<a href="<?php echo $trustindex_collector->get_feedback_url(); ?>" target="_blank" class="btn btn-light" id="ti-feedback-form-url">
<?php echo TrustindexCollectorPlugin::___('Preview feedback form'); ?>
<span class="dashicons dashicons-external"></span>
</a>
</div>
</div>
<?php if(!$trustindex_collector->is_campaign_active()): ?>
<div class="row">
<div class="col justify-content-end d-flex">
<a href="<?php echo esc_url('?page='. $_page .'&tab=dashboard'); ?>" class="btn btn-primary btn-next btn-finish"><?php echo __('Start e-mail campaign'); ?></a>
</div>
</div>
<?php endif; ?>
</div>
</form>
</div>
</div>
</div>
<div id="platform-url-template" class="row g-2 platform-url d-none">
<div class="col-12 col-sm col-input">
<input type="text" name="platform-url[][url]" class="form-control" data-placeholder="<?php echo TrustindexCollectorPlugin::___('click to connect Google URL'); ?>" data-placeholder-custom="<?php echo TrustindexCollectorPlugin::___('type a custom URL (e.g. %s)', [ 'https://example.com']); ?>" />
<select class="form-select">
<option value="google">Google</option>
<option value="custom"><?php echo TrustindexCollectorPlugin::___('Custom'); ?></option>
</select>
<img src="https://cdn.trustindex.io/assets/platform/Google/icon.svg" class="source-icon" alt="Google" />
<a href="#" class="btn btn-success" data-change-text="<?php echo TrustindexCollectorPlugin::___('Change'); ?>" data-connect-text="<?php echo TrustindexCollectorPlugin::___('Connect'); ?>"></a>
</div>
<div class="col-auto col-percent">
<select class="form-select" name="platform-url[][percent]" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo TrustindexCollectorPlugin::___('Review URL probability'); ?>">
<?php for($i = 0; $i <= 100; $i+=5): ?>
<option value="<?php echo $i; ?>"><?php echo $i; ?>%</option>
<?php endfor; ?>
</select>
</div>
<div class="col-auto col-preview">
<button type="button" class="btn btn-light btn-test-review-link" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo TrustindexCollectorPlugin::___('Preview URL'); ?>" disabled>
<span class="dashicons dashicons-external"></span>
</button>
</div>
<div class="col-auto col-remove">
<a href="#" class="btn btn-light btn-remove-platform-url" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo TrustindexCollectorPlugin::___('Delete URL'); ?>">
<span class="dashicons dashicons-remove"></span>
</a>
</div>
</div>
<!-- Source Connect Modal -->
<div class="modal fade" id="modal-source-import" tabindex="-1" role="dialog">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title"><?php echo TrustindexCollectorPlugin::___('Google Business Profile name or location'); ?></h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo TrustindexCollectorPlugin::___('Close'); ?>"></button>
</div>
<div class="modal-body">
<iframe alt-src="https://admin.trustindex.io/integration/wordpressSourceConnect?type=google" scrolling="no" style="width: 100%; height: 0; overflow: hidden; border: 0" allowfullscreen="true"></iframe>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo TrustindexCollectorPlugin::___('Close'); ?></button>
<button type="button" class="btn btn-primary btn-source-connect btn-loading-animation-on-click" disabled><?php echo TrustindexCollectorPlugin::___('Select'); ?></button>
</div>
</div>
</div>
</div>