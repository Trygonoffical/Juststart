<?php
defined('ABSPATH') or die('No script kiddies please!');
wp_enqueue_script('trustindex-js', 'https://cdn.trustindex.io/loader.js', [], false, true);
?>
<div class="plugin-body">
<div class="card">
<div class="card-header card-header-lg"><?php echo TrustindexCollectorPlugin::___('Skyrocket Your Sales with Customer Reviews'); ?></div>
<div class="card-body">
<p class="size-18"><?php echo TrustindexCollectorPlugin::___('%s+ businesses use Trustindex to collect and embed reviews easily.', [ '100.000' ]) .' '. TrustindexCollectorPlugin::___('Increase SEO, trust and sales using customer reviews.'); ?></p>
<p class="size-18"><?php echo TrustindexCollectorPlugin::___('Display your reviews with our beautiful, easy-to-integrate and mobile responsive widgets.') .' '. TrustindexCollectorPlugin::___('Choose from %d layouts and %d pre-designed styles.', [ 40, 25 ]); ?></p>
<a class="btn btn-primary" href="https://www.trustindex.io/ti-redirect.php?a=sys&c=wc-collect-2" target="_blank"><?php echo TrustindexCollectorPlugin::___('Create a free Trustindex account'); ?></a>
</div>
</div>
<div class="row">
<div class="col plugin-subtitle"><?php echo TrustindexCollectorPlugin::___('The 5 most popular Google widgets'); ?></div>
</div>
<div class="card card-widget">
<div class="card-header card-header-sm"><?php echo TrustindexCollectorPlugin::___('Slider I.'); ?></div>
<div class="card-body">
<div src='https://cdn.trustindex.io/loader.js?63921e6798e5959c2f51bff7dd'></div>
</div>
</div>
<div class="card card-widget">
<div class="card-header card-header-sm"><?php echo TrustindexCollectorPlugin::___('Slider I. - centered'); ?></div>
<div class="card-body">
<div src='https://cdn.trustindex.io/loader.js?8a6fe827949e9600ef586576e0'></div>
</div>
</div>
<div class="card card-widget">
<div class="card-header card-header-sm"><?php echo TrustindexCollectorPlugin::___('Slider III. - with badge'); ?></div>
<div class="card-body">
<div src='https://cdn.trustindex.io/loader.js?87d2bf67974f9615e15e03cdee'></div>
</div>
</div>
<div class="card card-widget">
<div class="card-header card-header-sm"><?php echo TrustindexCollectorPlugin::___('Mansonry grid'); ?></div>
<div class="card-body">
<div src='https://cdn.trustindex.io/loader.js?b2d8a2079324962b235708937d'></div>
</div>
</div>
<div class="card card-widget">
<div class="card-header card-header-sm"><?php echo TrustindexCollectorPlugin::___('List I.'); ?></div>
<div class="card-body">
<div src='https://cdn.trustindex.io/loader.js?b7ec04e794fd963e3954d629ee'></div>
</div>
</div>
<div class="row">
<div class="col plugin-subtitle text-center"><?php echo TrustindexCollectorPlugin::___('Embed review widgets to your website!'); ?></div>
</div>
<div class="btn-container center">
<a href="https://www.trustindex.io/ti-redirect.php?a=sys&c=wc-collect-3" target="_blank" class="btn btn-primary"><?php echo TrustindexCollectorPlugin::___('Create a free Trustindex account'); ?></a>
</div>
</div>