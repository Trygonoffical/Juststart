<?php
defined('ABSPATH') or die('No script kiddies please!');
$list_page_index = isset($_REQUEST['pi']) ? intval($_REQUEST['pi']) : 1;
$list_page_term = isset($_REQUEST['q']) ? sanitize_text_field($_REQUEST['q']) : "";
$page_url = "?page=$_page&tab=$_tab&pi=$list_page_index&q=$list_page_term";
if(isset($_GET['cancel']))
{
$id = intval($_GET['cancel']);
$wpdb->delete($trustindex_collector->get_tablename('unsubscribes'), [ 'id' => $id ]);
header('Location: '. $page_url);
exit;
}
$results = $trustindex_collector->get_unsubscribes($list_page_index, $list_page_term);
if($list_page_term)
{
$results_total = $trustindex_collector->get_unsubscribes()->total;
}
else
{
$results_total = $results->total;
}
?>
<div class="plugin-head"><?php echo TrustindexCollectorPlugin::___('Unsubscribes'); ?></div>
<div class="plugin-body table-list">
<?php if($results_total): ?>
<form class="row justify-content-end">
<input type="hidden" name="page" value="<?php echo esc_attr($_page); ?>" />
<input type="hidden" name="tab" value="<?php echo esc_attr($_tab); ?>" />
<input type="hidden" name="pi" value="1" />
<div class="col-3">
<input type="text" class="form-control" autofocus name="q" value="<?php echo esc_attr($list_page_term); ?>" placeholder="<?php echo TrustindexCollectorPlugin::___('Search'); ?>" />
</div>
<div class="col-2 col-sm-auto">
<button class="btn btn-primary btn-loading-on-click"><?php echo TrustindexCollectorPlugin::___('Search'); ?></button>
</div>
</form>
<?php endif; ?>
<?php if($results->total): ?>
<div class="table-container">
<table class="table ti-table">
<thead>
<tr>
<th scope="col"><?php echo TrustindexCollectorPlugin::___('E-mail'); ?></th>
<th scope="col" style="width: 200px"><?php echo TrustindexCollectorPlugin::___('Created date'); ?></th>
<th scope="col" style="width: 100px" class="text-center"><?php echo TrustindexCollectorPlugin::___('Cancel'); ?></th>
</tr>
</thead>
<tbody>
<?php foreach($results->unsubscribes as $unsubscribe): ?>
<tr>
<td><?php echo esc_html($unsubscribe->email); ?></td>
<td><?php echo date('Y-m-d H:i:s', strtotime($unsubscribe->created_at)); ?></td>
<td class="text-center">
<a href="<?php echo esc_url($page_url .'&cancel='. $unsubscribe->id); ?>" class="btn btn-danger btn-sm btn-loading-on-click">
<span class="dashicons dashicons-trash"></span>
</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php if($results->max_num_pages > 1): ?>
<?php include($trustindex_collector->get_plugin_dir() . 'include' . DIRECTORY_SEPARATOR . 'pagination.php'); ?>
<?php endif; ?>
<?php else: ?>
<div class="alert alert-warning">
<p><?php echo TrustindexCollectorPlugin::___('List is empty.'); ?></p>
</div>
<?php endif; ?>
</div>